# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0

{{- define "backend-operator.injectOTEL" -}}
{{- if .Values.sidecars.OTEL.enabled }}
- name: otc-container
  image: "{{ .Values.sidecars.OTEL.image }}"
  securityContext:
    allowPrivilegeEscalation: false
    capabilities:
      drop: ["ALL"]
    runAsNonRoot: true
    runAsUser: 10001

  imagePullPolicy: IfNotPresent
  args:
  - --config=/conf/collector.yaml
  ports:
  {{ toYaml .Values.sidecars.OTEL.ports | nindent 2}}
  volumeMounts:
  - mountPath: /conf
    name: config
  livenessProbe:
    httpGet:
      path: /metrics
      port: 4000
      scheme: HTTP
    periodSeconds: 30
    timeoutSeconds: 1
    failureThreshold: 3
    successThreshold: 1
  resources:
  {{- toYaml .Values.sidecars.OTEL.resources | nindent 4 }}
{{- end }}
{{- end }}

{{- define "backend-operator.OTELVolumes" -}}
{{- $prefix := .Prefix }}
{{- if .Values.sidecars.OTEL.enabled}}
- name: config
  configMap:
    name: {{ if $prefix }}{{ $prefix }}-{{ end }}{{ .Values.sidecars.OTEL.configName }}
    defaultMode: 420
    items:
    - key: collector.yaml
      path: collector.yaml
{{- end }}
{{- end }}
